import hashlib
import random
import time
from datetime import datetime

class Nodo:
    def __init__(self, partida, cuerpo, firma):
        self.partida=partida
        self.cuerpo=cuerpo
        self.firma=firma

def obtener_fecha_actual():
    ahora=datetime.now()
    return ahora.strftime("%d/%m/%Y %H:%M")

def generar_cuerpo(k):
    return [random.randint(1, 100000) for _ in range(k)]

def construir_texto_para_hash(partida, cuerpo):
    return partida+" "+" ".join(map(str, cuerpo))

def hash_string(input_str):
    return hashlib.sha256(input_str.encode('utf-8')).hexdigest()

def main():
    start=time.time()
    # profe
    n=3
    k=4
    lista=[]
    partida=obtener_fecha_actual()

    for _ in range(n):
        cuerpo=generar_cuerpo(k)
        texto_hash=construir_texto_para_hash(partida, cuerpo)
        firma=hash_string(texto_hash)
        nodo=Nodo(partida, cuerpo, firma)
        lista.append(nodo)
        partida=firma

    for i, nodo in enumerate(lista, start=1):
        print(f"nodo{i}:")
        print(f"partida: {nodo.partida}")
        print(f"cuerpo: {' '.join(map(str, nodo.cuerpo))}")
        print(f"firma: {nodo.firma}\n")

    end = time.time()
    duration_ms=(end-start)*1000
    print(f"tiempo de ej: {duration_ms:.3f} ms")

if __name__ == "__main__":
    main()
