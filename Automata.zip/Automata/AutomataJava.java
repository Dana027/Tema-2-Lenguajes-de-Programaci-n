import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

public class AutomataListaEnlazada{
    static class Nodo{
        String partida;
        List<Integer> cuerpo;
        String firma;
        Nodo siguiente;

        public Nodo(String partida, List<Integer> cuerpo, String firma){
            this.partida=partida;
            this.cuerpo=cuerpo;
            this.firma=firma;
        }
    }

    public static String sha256(String texto){
        try{
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            byte[] hash=digest.digest(texto.getBytes("UTF-8"));
            StringBuilder hex=new StringBuilder();
            for(byte b : hash) {
                hex.append(String.format("%02x", b)); }
            return hex.toString();
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    public static Nodo crearLista(int n, int k){
        Random random=new Random();
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String fechaInicial=sdf.format(new Date());

        List<Integer> cuerpoInicial=new ArrayList<>();
        for(int i=0;i<k;i++){
            cuerpoInicial.add(random.nextInt(100_000)+1); }

        StringBuilder sbInicial=new StringBuilder(fechaInicial);
        for(int num:cuerpoInicial){
            sbInicial.append(" ").append(num); }
        String firmaInicial=sha256(sbInicial.toString());
        Nodo cabeza=new Nodo(fechaInicial, cuerpoInicial, firmaInicial);
        Nodo actual=cabeza;


        for(int i=1;i<n;i++) {
            List<Integer>cuerpo=new ArrayList<>();
            for(int j=0;j<k;j++) {
                cuerpo.add(random.nextInt(100_000)+1); }

            StringBuilder sb=new StringBuilder(actual.firma);
            for(int num:cuerpo){
                sb.append(" ").append(num); }

            String firma=sha256(sb.toString());
            Nodo nuevo=new Nodo(actual.firma, cuerpo, firma);
            actual.siguiente=nuevo;
            actual=nuevo; }

        return cabeza;
    }

    public static void imprimirLista(Nodo cabeza){
        Nodo actual=cabeza;
        int i=1;
        while (actual != null) {
            System.out.println("nodo " + i++);
            System.out.println("partida: "+actual.partida);
            System.out.println("cuerpo: "+actual.cuerpo);
            System.out.println("firma:  "+actual.firma);
            System.out.println();
            actual=actual.siguiente;
        }
    }

    public static void main(String[] args){
        // delprofe
        int n=3; int k=4;
        long inicio=System.currentTimeMillis();
        Nodo lista=crearLista(n, k);
        long fin=System.currentTimeMillis();
        imprimirLista(lista);
        System.out.println("tiempo de ej: "+(fin-inicio)+" ms");
    }
    
}